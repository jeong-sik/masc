Requested focused verification: PASS, 4/4 cases, on freshly built patched local be37 candidate.

Identity:
- Base HEAD be37f5af998adb7b9825bbf2549910eb12f3cfcd.
- Input archive SHA256 4359e952bad35068b6fd293c0034ef8b397760b5d255784dea94a756ebbf5d9f; bundle verify succeeded with available parents409477786bee05ef3103146058a7200e65ec892e and109e1b6db42f44d049c3b206719ea2942da3c67a.
- Applied only provided repair.patch SHA25608a1dc928f03049c9376fca14e524a3dae1dc4948d761ddaab59f6ad847d9335.
- bin/masc_tui.ml SHA256 dcb1467f9b68847514072cbc212720ae459269f70e69634350103361884ca7d2.
- test/test_tui_keeper_portrait_pty.py SHA256715da737aa142855cd8dbcc66a431cbe11914da256b434d179ca0869ad6587a5.
- Own detached worktree review40754.git/.worktrees/partial-transition-be37. Only those two source files modified.
- Own pre-existing OPAMROOT native41001-isolated/opam-root, switch native41001-5.5.1; OCaml5.5.1. Candidate guard: all10 pins in place. No shared-switch writes, repinning, skipped guards or host config changes.
- Fresh release-profile binary135,723,840B, SHA2562f503fb1f82001bbbc3dcbc9087d37e771094563c0c3b37b9c80dd2400969b8e. This identity is be37 plus the two-file working-tree patch, not unpatched be37.

Execution:
opam exec --set-switch -- bash scripts/dune-local.sh build bin/masc_tui.exe --profile release
exit0;2026-10-03T19:13:56.521729Z to19:16:27.658154Z;151.134950 seconds.

Cases executed separately by module import (no module __main__ or wide-suite invocation), binary and source hashes bound in each receipt:
1. item_account_survives_partial_roster_refresh(binary): exit0;3.329172s;19:16:58.401539Z–19:17:01.730786Z.
2. Same with initially_present=True: exit0;3.351586s;19:17:01.731737Z–19:17:05.083427Z.
3. item_account_follows_private_changes(binary): exit0;2.909939s;19:17:05.084103Z–19:17:07.994122Z.
4. test_tui_item_workspace_authority_pty.run_partial_roster(binary,Path(captures)): exit0;4.397254s;19:17:07.996520Z–19:17:12.399159Z.

Each stdout/stderr, full argv/cwd/times/exit and log hashes are stored in <case>.json/stdout/stderr. RUNNER_TEMP and captures are in separate case-owned subdirectories;19 capture files include raw PTY, visible text and HTTP request records. The first two cases check retained12.500 balance,1.000 price/ownership across successive partial-roster ticks, exactly one held read, the original held response drawing13.000, then503 roster refusal removing monetary/ownership facts. The private-change case checks automatic purchase/price refresh and retention of a slow read's ticket. These are fresh-binary fixture PTY results, not installed-server/live-account proof.

Source-only independent verdict: PASS for the exact two-file patch, separately from execution.
refresh_changed_keeper_items:3624-3648 narrows revision change to actual authority/change signals. Partial omission is recognized only during roster refresh, with previous/current visible keeper and canonical workspace identity equal and current typed liveness Unobserved. It avoids replacing a pending Detail_items request; once settled it still schedules ordinary account cadence. launch_keeper_items retains its existing workspace/readiness/roster-unread/Absent/Invalid refusal guards and fresh request generation. Current explicit failure handling still withdraws authoritative facts; executed503 checks confirm that requested boundary. The modified fixture introduces initially-present-to-partial without weakening balance, price, ownership, one-held-read, original-response or failure-withdrawal assertions; existing private-change body is unchanged. No new P0/P1/P2 found in this inspected delta. Other candidate source is outside this independent verdict. This is not a formal GitHub approval or a FullRC/release verdict.

Peer baseline: input/partial-transition/before.* and its raw PTY are preserved as attributed peer evidence. The reported baseline c338 failure is not a reproduction performed by this verifier, nor a same-tree performance comparison.

Limits: only the requested four cases ran. No source changes beyond applying the supplied patch, commit/push/PR/merge/FullRC/wide suites/release/deployment. The source files and binary were hashed again after execution. The packet contains source/patch and evidence; it does not contain the135MB binary.

[근거] own candidate bundle verification, pinned guarded build, actual fresh binary four-case PTY execution, observed capture texts and after-run hashes;2026-10-03 19:13–19:18UTC;High for this exact patched candidate and focused fixture scope.
— masc-pro-builder
