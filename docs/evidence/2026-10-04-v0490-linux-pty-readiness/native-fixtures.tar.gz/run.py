from pathlib import Path
import hashlib,json,os,runpy,sys,time,traceback
root=Path(sys.argv[1]).resolve();binary=Path(sys.argv[2]).resolve();out=Path(sys.argv[3]).resolve();out.mkdir(parents=True,exist_ok=True)
os.environ['RUNNER_TEMP']=str(out);sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'test'))
import test_tui_keyboard_input as h
suites=['test_tui_board_scroll.py','test_tui_keeper_portrait_pty.py','test_tui_home_failure_task_pty.py']
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'test'/n for n in suites+['test_tui_keyboard_input.py','test_tui_home_decision_cards_pty.py','test_tui_home_journey_pty.py']]}
rows=[];errors=[];handle=h.FixtureHTTPServer.handle_error
started=time.time()
def record_error(self,*args):
 error=sys.exc_info()[1];errors.append({'type':type(error).__name__,'detail':str(error),'expected_disconnect':isinstance(error,(BrokenPipeError,ConnectionResetError))});return handle(self,*args)
h.FixtureHTTPServer.handle_error=record_error
original=h.run_terminal_scenario
def capture(*args,**kwargs):
 n=len(rows)+1;r={'description':kwargs['description'],'status':'running','started_at':time.time()};rows.append(r);f=kwargs['interact']
 def interact(proc,fd,slave,output,base):
  r['pid']=proc.pid
  try:return f(proc,fd,slave,output,base)
  finally:
   (out/f'{n:02}.pty').write_bytes(output);(out/f'{n:02}.txt').write_bytes(h.screen_text(bytes(output)))
 kwargs['interact']=interact
 try:result=original(*args,**kwargs);r['status']='PASS';return result
 except BaseException as ex:r['status']='FAIL';r['error']=str(ex).split(": b'")[0][:1600];raise
 finally:
  r['finished_at']=time.time();(out/'scenarios.json').write_text(json.dumps(rows,indent=2)+'\n');print(n,r['description'],r['status'],flush=True)
h.run_terminal_scenario=capture
status=0
try:
 for suite in suites:
  sys.argv=[str(root/'test'/suite),str(binary)];runpy.run_path(sys.argv[0],run_name='__main__')
except BaseException:
 status=1;traceback.print_exc()
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==digest for n,digest in sources.items())
status=max(status,int(any(not e['expected_disconnect'] for e in errors)))
result={'scope':'Complete official Board, portrait and Home-failure fixture entrypoints with actual RC4a Linux-arm64 binary. Source-only readiness/GET fixture repair overlay; not a new binary, x64 proof or Full RC.','binary_commit':'4a5517c1dac84d941cb99a7b89eafe1c61b384dd','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':sources,'fixture_errors':errors,'exit_code':status,'scenarios':len(rows),'passed':sum(r['status']=='PASS' for r in rows),'started_at':started,'finished_at':time.time()}
(out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');sys.exit(status)
