from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,traceback
root=Path(sys.argv[1]);binary=Path(sys.argv[2]);out=Path(sys.argv[3]);mode=sys.argv[4];out.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'test'));os.environ['RUNNER_TEMP']=str(out)
import test_tui_keyboard_input as h
import test_tui_board_scroll as board
original=h.run_terminal_scenario;events=[]
def delayed(*args,**kwargs):
 fixtures=kwargs['http_fixtures'];response=fixtures['/api/v1/board?sort_by=hot']
 def read_list():
  admitted=time.monotonic();time.sleep(1.0);events.append({'admitted':admitted,'released':time.monotonic()});return response
 fixtures['/api/v1/board?sort_by=hot']=read_list
 interact=kwargs['interact']
 def capture(process,fd,slave,output,base):
  try:return interact(process,fd,slave,output,base)
  finally:(out/'terminal.pty').write_bytes(output);(out/'screen.txt').write_bytes(h.screen_text(bytes(output)))
 kwargs['interact']=capture;return original(*args,**kwargs)
h.run_terminal_scenario=delayed
status='PASS';error=None
try:board.run_independent_windows(str(binary))
except AssertionError as e:status='FAIL';error=str(e).split(": b'")[0]
assert events and all(e['released']-e['admitted']>=1.0 for e in events)
if mode=='baseline':assert status=='FAIL' and "Comment row 000" in error,(status,error)
else:assert status=='PASS',(status,error)
r={'mode':mode,'scope':'Actual RC4a Linux-arm64 native TUI with a one-second legitimate Board list response; all original scenario assertions retained. Baseline must fail before row readiness; repaired scenario must pass.','status':status,'expected_result_observed':True,'error':error,'events':events,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256((root/'test/test_tui_board_scroll.py').read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
