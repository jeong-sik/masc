from pathlib import Path
import hashlib,json,os,sys,threading,time,urllib.request
root=Path('/Users/dancer/me/workspace/yousleepwhen/masc-v0490-pty-async-barriers-20261004')
binary=Path('/tmp/masc-v0490-residual-fixtures-20261004/rc37142285007/masc-macos-arm64/masc-tui-macos-arm64')
os.environ['DYLD_LIBRARY_PATH']=str(binary.parent/'lib');sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'test'))
import test_tui_item_workspace_authority_pty as item
h=item.h;original=h.send_and_wait;workers=[];injected=[]
def send(process,fd,output,payload,needle,*args,**kw):
 result=original(process,fd,output,payload,needle,*args,**kw)
 if payload==b'k' and needle==b'Items 1/18' and not workers:
  port=process.args[process.args.index('--port')+1]
  def inject():
   time.sleep(0.25)
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/v1/keepers/alpha/items',timeout=3) as response:
    injected.append(response.status);response.read()
  worker=threading.Thread(target=inject);workers.append(worker);worker.start()
 return result
h.send_and_wait=send
try:
 item.run(str(binary),None)
 raise RuntimeError('negative control unexpectedly passed')
except AssertionError as ex:
 expected='explicit Item retry asynchronously read the account without roster authority'
 assert expected in str(ex),str(ex)[:1000]
 for w in workers:w.join(3)
 assert injected==[200],injected
 result={'scope':'harness negative control; injected HTTP GET 250ms after the keyboard frame, not a product-originated request','status':'PASS_EXPECTED_REJECTION','assertion':expected,'injected_http_status':injected,'source_sha256':hashlib.sha256((root/'test/test_tui_item_workspace_authority_pty.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 Path(__file__).with_name('result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
