import pathlib,subprocess,hashlib,json,tarfile,datetime,shutil
root=pathlib.Path.cwd();out=root/"partial-transition-verify";wt=root/"review40754.git/.worktrees/partial-transition-be37"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((out/"identity.json").read_text());binding=json.loads((out/"binary.json").read_text());tests=json.loads((out/"test-result.json").read_text())
assert tests["passed"]==4 and tests["requested"]==4
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=wt,text=True).strip()==identity["head"]
for f,h in identity["source_hashes"].items():
    assert sha(wt/f)==h
    dst=out/"source"/f;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(wt/f,dst)
assert sha(pathlib.Path(binding["path"]))==binding["sha256"]
diff=subprocess.check_output(["git","diff"],cwd=wt);(out/"applied.diff").write_bytes(diff)
paths=subprocess.check_output(["git","diff","--name-only"],cwd=wt,text=True).splitlines();assert sorted(paths)==sorted(identity["source_hashes"])
status=subprocess.check_output(["git","status","--porcelain"],cwd=wt,text=True)
checks=subprocess.run(["git","diff","--check"],cwd=wt,capture_output=True,text=True);assert checks.returncode==0
fixture_paths=["test/test_tui_item_workspace_authority_pty.py","test/test_tui_keyboard_input.py","bin/masc_tui_keeper_control.ml"]
env={"head":identity["head"],"head_commit":subprocess.check_output(["git","show","-s","--format=%H %P %T",identity["head"]],cwd=wt,text=True).strip(),"patch_sha256":sha(out/"input/partial-transition/repair.patch"),"applied_diff_sha256":hashlib.sha256(diff).hexdigest(),"binary_sha256":sha(pathlib.Path(binding["path"])),"source_hashes":identity["source_hashes"],"fixture_dependency_hashes":{f:sha(wt/f) for f in fixture_paths},"worktree_status":status,"diff_check":checks.returncode,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/"after.json").write_text(json.dumps(env,ensure_ascii=False,indent=2)+"\n")
captures=list((out/"captures").rglob("*"));assert sum(p.is_file() for p in captures)==19
files=sorted(p for p in out.rglob("*") if p.is_file() and p.name not in ["result.tar.gz","archive-receipt.json","files.json"])
listing=[{"path":str(p.relative_to(out)),"bytes":p.stat().st_size,"sha256":sha(p)} for p in files]
(out/"files.json").write_text(json.dumps(listing,ensure_ascii=False,indent=2)+"\n")
files.append(out/"files.json")
archive=out/"result.tar.gz"
with tarfile.open(archive,"w:gz") as t:
    for p in files:t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as t:
    for row in listing:
        data=t.extractfile(row["path"]).read()
        assert len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"]
receipt={"archive_sha256":sha(archive),"bytes":archive.stat().st_size,"files":len(files),"captures":19,"source_verdict":"PASS scope: provided two-file delta","focused_verification":"PASS 4/4 fixture PTY cases","binary_sha256":binding["sha256"],"head":identity["head"],"patch_sha256":identity["patch_sha256"],"utc":env["utc"]}
(out/"archive-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
