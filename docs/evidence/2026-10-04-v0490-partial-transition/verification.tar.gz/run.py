import os,pathlib,subprocess,json,hashlib,datetime,time,sys
root=pathlib.Path.cwd()
out=root/"partial-transition-verify"
wt=root/"review40754.git/.worktrees/partial-transition-be37"
opam_root=root/"native41001-isolated/opam-root"
env=os.environ.copy()
env.update(OPAMROOT=str(opam_root),OPAMSWITCH="native41001-5.5.1",DUNE_JOBS="2",MASC_DUNE_CACHE="disabled")
for k in ["MASC_SKIP_DEPS_CHECK","MASC_SKIP_OCAML_VERSION_CHECK","MASC_DUNE_DRY_RUN","GITHUB_ACTIONS","DUNE_ROOT","DUNE_BUILD_DIR"]:env.pop(k,None)
head="be37f5af998adb7b9825bbf2549910eb12f3cfcd"
expected={"bin/masc_tui.ml":"dcb1467f9b68847514072cbc212720ae459269f70e69634350103361884ca7d2","test/test_tui_keeper_portrait_pty.py":"715da737aa142855cd8dbcc66a431cbe11914da256b434d179ca0869ad6587a5"}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+"\n")
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=wt,text=True).strip()==head
for f,h in expected.items():assert sha(wt/f)==h,(f,sha(wt/f))
assert sha(out/"input/partial-transition/repair.patch")=="08a1dc928f03049c9376fca14e524a3dae1dc4948d761ddaab59f6ad847d9335"
changed=subprocess.check_output(["git","diff","--name-only"],cwd=wt,text=True).splitlines()
assert sorted(changed)==sorted(expected)
save(out/"identity.json",{"head":head,"worktree":str(wt),"opam_root":str(opam_root),"switch":env["OPAMSWITCH"],"patch_sha256":sha(out/"input/partial-transition/repair.patch"),"source_hashes":expected,"input_tar_sha256":sha(out/"input.tar.gz"),"utc":now()})
def run(name,argv,extra_env=None):
    e=env.copy()
    if extra_env:e.update(extra_env)
    rec={"stage":name,"argv":argv,"cwd":str(wt),"started_at":now(),"head":head,"source_hashes":expected,"opam_root":str(opam_root),"switch":env["OPAMSWITCH"]}
    save(out/(name+".json"),rec)
    t=time.monotonic()
    with (out/(name+".stdout")).open("wb") as stdout,(out/(name+".stderr")).open("wb") as stderr:
        p=subprocess.run(argv,cwd=wt,env=e,stdout=stdout,stderr=stderr)
    rec.update(exit=p.returncode,finished_at=now(),wall_seconds=time.monotonic()-t)
    for s in ["stdout","stderr"]:rec[s+"_sha256"]=sha(out/(name+"."+s))
    save(out/(name+".json"),rec)
    print(json.dumps(rec),flush=True)
    return p.returncode
if sys.argv[1]=="build":
    assert run("toolchain",["opam","exec","--set-switch","--","ocamlc","-version"])==0
    assert run("pins",["opam","exec","--set-switch","--","bash","scripts/opam-pin-external-deps.sh","--check"])==0
    code=run("build",["opam","exec","--set-switch","--","bash","scripts/dune-local.sh","build","bin/masc_tui.exe","--profile","release"])
    if code==0:
        binary=wt/"_build/default/bin/masc_tui.exe"
        save(out/"binary.json",{"path":str(binary),"sha256":sha(binary),"bytes":binary.stat().st_size,"utc":now(),"head":head,"source_hashes":expected})
    sys.exit(code)
else:
    binary=wt/"_build/default/bin/masc_tui.exe"
    binding=json.loads((out/"binary.json").read_text());assert sha(binary)==binding["sha256"]
    cases=[
      ("partial_initial","import test_tui_keeper_portrait_pty as t;t.item_account_survives_partial_roster_refresh(binary)"),
      ("present_to_partial","import test_tui_keeper_portrait_pty as t;t.item_account_survives_partial_roster_refresh(binary,initially_present=True)"),
      ("private_changes","import test_tui_keeper_portrait_pty as t;t.item_account_follows_private_changes(binary)"),
      ("workspace_authority","import test_tui_item_workspace_authority_pty as t;t.run_partial_roster(binary,Path(captures))")]
    results={}
    for name,call in cases:
        cap=out/"captures"/name;cap.mkdir(parents=True,exist_ok=True)
        script="import sys;from pathlib import Path;sys.path.insert(0,'test');binary=sys.argv[1];captures=sys.argv[2];"+call
        results[name]=run(name,["python3","-c",script,str(binary),str(cap)],{"RUNNER_TEMP":str(cap),"PYTHONDONTWRITEBYTECODE":"1"})
    save(out/"test-result.json",{"results":results,"binary_sha256":sha(binary),"utc":now(),"source_hashes":expected,"head":head,"passed":sum(x==0 for x in results.values()),"requested":4})
    print(json.dumps(results))
    sys.exit(0 if all(x==0 for x in results.values()) else 1)
